1. Exporter le module H5P sous format .html en utilisant le logiciel Lumi (https://lumi.education/)
2. Importer le fichier html dans le dossier /sources 
3. Dans le fichier index.html ajouter le lien vers le module H5P se trouvant dans le dossier /sources
4. Pour l'intégration : Copier l'adresse URL du module H5P depuis le site Github et ajouter les balises iFrame : <iframe src="Lien URL du site" ></iframe>
